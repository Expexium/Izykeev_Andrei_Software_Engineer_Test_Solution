// Copyright Epic Games, Inc. All Rights Reserved.

#include "Redruins_TT_2024.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Redruins_TT_2024, "Redruins_TT_2024" );
